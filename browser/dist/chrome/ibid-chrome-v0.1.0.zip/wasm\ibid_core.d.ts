/* tslint:disable */
/* eslint-disable */

/**
 * WASM-exposed citation engine
 */
export class IbidEngine {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Add a single citation item from JSON string
     */
    addItem(json: string): void;
    /**
     * Clear all items
     */
    clearItems(): void;
    /**
     * Export items as BibTeX. Input: JSON array of CSL-JSON items. Options: JSON { includeAbstract, includeKeywords }
     */
    exportBibtex(items_json: string, options_json: string): string;
    /**
     * Export as CSV
     */
    exportCsv(items_json: string, delimiter: string): string;
    /**
     * Export items as RIS. Input: JSON array of CSL-JSON items.
     */
    exportRis(items_json: string): string;
    /**
     * Export as Word XML Bibliography
     */
    exportWordXml(items_json: string): string;
    /**
     * Export as YAML
     */
    exportYaml(items_json: string): string;
    /**
     * Extract text from PDF bytes
     */
    extractPdfText(bytes: Uint8Array): string;
    /**
     * Format all loaded items as a bibliography, returns JSON array of strings
     */
    formatBibliography(): string;
    /**
     * Format a single item as a bibliography entry (by item ID)
     */
    formatBibliographyEntry(item_json: string): string;
    /**
     * Format an in-text citation for given item IDs (JSON array of item JSON objects)
     */
    formatCitation(items_json: string): string;
    /**
     * Get item count
     */
    getItemCount(): number;
    /**
     * Get loaded style info as JSON
     */
    getStyleInfo(): string;
    /**
     * Load a CSL locale from XML string
     */
    loadLocale(xml: string): void;
    /**
     * Load a CSL style from XML string
     */
    loadStyle(xml: string): void;
    /**
     * Create a new engine with default English locale
     */
    constructor();
    /**
     * Parse BibTeX string, returns JSON: { entries: [...CSL-JSON], errors: [...] }
     */
    parseBibtex(input: string): string;
    /**
     * Parse CSL-JSON string (passthrough with validation), returns JSON
     */
    parseCslJson(input: string): string;
    /**
     * Parse CSV/TSV. delimiter: "," or "\t"
     */
    parseCsv(input: string, delimiter: string): string;
    /**
     * Parse EndNote XML
     */
    parseEndnoteXml(input: string): string;
    /**
     * Parse MEDLINE/NBIB
     */
    parseMedline(input: string): string;
    /**
     * Parse RIS string, returns JSON: { entries: [...CSL-JSON], errors: [...] }
     */
    parseRis(input: string): string;
    /**
     * Set output format: "html" or "text"
     */
    setFormat(format: string): void;
    /**
     * Set citation items from JSON string (array of CSL-JSON items)
     */
    setItems(json: string): void;
}

export function version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_ibidengine_free: (a: number, b: number) => void;
    readonly ibidengine_addItem: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_clearItems: (a: number) => void;
    readonly ibidengine_exportBibtex: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ibidengine_exportCsv: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ibidengine_exportRis: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_exportWordXml: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_exportYaml: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_extractPdfText: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_formatBibliography: (a: number, b: number) => void;
    readonly ibidengine_formatBibliographyEntry: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_formatCitation: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_getItemCount: (a: number) => number;
    readonly ibidengine_getStyleInfo: (a: number, b: number) => void;
    readonly ibidengine_loadLocale: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_loadStyle: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_new: () => number;
    readonly ibidengine_parseBibtex: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_parseCslJson: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_parseCsv: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ibidengine_parseEndnoteXml: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_parseMedline: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_parseRis: (a: number, b: number, c: number, d: number) => void;
    readonly ibidengine_setFormat: (a: number, b: number, c: number) => void;
    readonly ibidengine_setItems: (a: number, b: number, c: number, d: number) => void;
    readonly version: (a: number) => void;
    readonly __wbindgen_export: (a: number) => void;
    readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
    readonly __wbindgen_export2: (a: number, b: number) => number;
    readonly __wbindgen_export3: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_export4: (a: number, b: number, c: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
